import discord
from discord.ext import commands, tasks
from discord.ui import Select, View
import json
import os
from dotenv import load_dotenv

# .env 파일에서 환경 변수 로드
load_dotenv()

# 봇 토큰 환경 변수에서 가져오기
TOKEN = os.getenv('MTI0ODY5NDM4MDE2OTEzODI0Ng.GWhiU_.unvSp0LCBN7RYQhdDlJrVj3WCnUoQ0vlZx5XHo')

# 파일에서 데이터를 로드하는 함수
def load_data(filename):
    if os.path.exists(filename):
        with open(filename, 'r') as file:
            return json.load(file)
    return {}

# 파일에 데이터를 저장하는 함수
def save_data(filename, data):
    with open(filename, 'w') as file:
        json.dump(data, file)

# 파일 경로
CODE_FILE = 'codes.json'
valid_codes = load_data(CODE_FILE)

RESERVATION_FILE = 'reservations.json'
reservations = load_data(RESERVATION_FILE)

# 채널 및 역할 설정
TICKET_REQUEST_CHANNEL_ID = 1267503788554453086  # 티켓 요청 채널 ID
TICKET_CATEGORY_ID = 1267482980629348442  # 티켓 카테고리 ID
RESERVATION_LOG_CHANNEL_ID = 1267494441145471090  # 예약 로그 채널 ID
ADMIN_ROLE_NAME = 'ADMIN'  # 관리자 역할 이름

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

# 티켓 드롭다운 메뉴
class TicketSelect(Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="💳ㅣ충전문의", value="충전문의", description="충전문의입니다."),
            discord.SelectOption(label="🔮ㅣ예약문의", value="예약문의", description="부스트 예약은 여기서 하세요."),
            discord.SelectOption(label="📁ㅣ기타문의", value="기타문의", description="기타 사항입니다.")
        ]
        super().__init__(placeholder="티켓 유형을 선택하세요...", min_values=1, max_values=1, options=options, custom_id="ticket_select")

    async def callback(self, interaction: discord.Interaction):
        category = discord.utils.get(interaction.guild.categories, id=TICKET_CATEGORY_ID)
        if not category:
            await interaction.response.send_message("티켓 카테고리를 찾을 수 없습니다.", ephemeral=True)
            return

        ticket_channel_name = f'티켓-{interaction.user.name}-{self.values[0]}'  # 채널 이름에 선택된 값 포함
        ticket_channel = await interaction.guild.create_text_channel(
            name=ticket_channel_name,
            category=category,
            overwrites={
                interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                interaction.user: discord.PermissionOverwrite(read_messages=True)
            }
        )

        await ticket_channel.send(f"안녕하세요 {interaction.user.mention}, 이곳에서 티켓을 관리하실 수 있습니다. 티켓 유형: {self.values[0]}")

        # 드롭다운 초기화
        new_select = TicketSelect()  # 새로운 드롭다운 생성
        view = View()
        view.add_item(new_select)

        await interaction.response.send_message(f"티켓이 생성되었습니다: {ticket_channel.mention}", ephemeral=True)
        await interaction.message.edit(content="티켓을 생성하려면 아래 드롭다운에서 유형을 선택하세요:", view=view)

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user}')
    # 티켓 드롭다운 메시지를 5분마다 보냄
    send_ticket_message.start()

@bot.command()
@commands.has_role('ADMIN')
async def 코드추가(ctx, *, codes: str):
    added_codes = []
    existing_codes = []

    for code in codes.split(','):
        code = code.strip()
        if code in valid_codes:
            existing_codes.append(code)
        else:
            valid_codes[code] = False
            added_codes.append(code)

    save_data(CODE_FILE, valid_codes)

    if added_codes:
        await ctx.send(f"{ctx.author.mention}, 다음 코드가 성공적으로 추가되었습니다: {', '.join(added_codes)}", delete_after=5)
    if existing_codes:
        await ctx.send(f"{ctx.author.mention}, 다음 코드는 이미 존재합니다: {', '.join(existing_codes)}", delete_after=5)

@bot.command()
async def 예약하기(ctx, code: str):
    code = code.strip()
    if code in valid_codes and not valid_codes[code]:
        valid_codes[code] = True
        save_data(CODE_FILE, valid_codes)

        try:
            await ctx.send(f"{ctx.author.mention}, 예약이 완료되었습니다! 예약로그 채널에 가서 인증사진과, 영구 서버링크를 가져와주세요!", delete_after=60)

            # 예약 정보 저장
            reservations[str(ctx.author.id)] = {
                'code': code,
                'channel_id': ctx.channel.id
            }
            save_data(RESERVATION_FILE, reservations)

            # 예약 로그 채널에 예약 완료 메시지 전송
            reservation_log_channel = bot.get_channel(1267494441145471090)
            if reservation_log_channel:
                await reservation_log_channel.send(f"{ctx.author.mention} 님이 예약을 완료했습니다.")
            else:
                await ctx.send(f"예약 로그 채널을 찾을 수 없습니다.", delete_after=5)
        except Exception as e:
            await ctx.send(f"예약 완료 메시지를 전송하는 중 오류가 발생했습니다: {e}", delete_after=5)
    else:
        await ctx.send(f"{ctx.author.mention}, 유효하지 않거나 이미 사용된 코드입니다.", delete_after=5)

@bot.command()
@commands.has_role('ADMIN')
async def 청소(ctx, amount: int):
    if ctx.author.guild_permissions.manage_messages:
        await ctx.channel.purge(limit=amount)
        # 청소 로그 메시지를 전송하지 않음
    else:
        await ctx.send(f"{ctx.author.mention}, 이 명령어를 사용하기 위한 권한이 없습니다.", delete_after=5)

@bot.command()
@commands.has_role('ADMIN')
async def 예약종료(ctx, user: discord.Member):
    user_id = str(user.id)
    if user_id in reservations:
        reservation_log_channel = bot.get_channel(1267494441145471090)
        if reservation_log_channel:
            try:
                async for message in reservation_log_channel.history(limit=100):
                    if message.author == bot.user and user.mention in message.content:
                        await message.edit(content=f"{user.mention}님의 예약이 종료되었습니다. 제품이 지급되었습니다.")
                        del reservations[user_id]
                        save_data(RESERVATION_FILE, reservations)

                        await ctx.send(f"{user.mention}님의 예약이 종료되었습니다. 제품이 지급되었습니다.", delete_after=5)
                        return
                await ctx.send(f"예약 완료 메시지를 찾을 수 없습니다.", delete_after=5)
            except discord.NotFound:
                await ctx.send(f"예약 완료 메시지를 찾을 수 없습니다.", delete_after=5)
            except discord.Forbidden:
                await ctx.send(f"예약 완료 메시지를 수정할 권한이 없습니다.", delete_after=5)
            except discord.HTTPException as e:
                await ctx.send(f"예약 메시지를 수정하는 중 HTTP 오류가 발생했습니다: {e}", delete_after=5)
            except Exception as e:
                await ctx.send(f"예약 메시지를 수정하는 중 오류가 발생했습니다: {e}", delete_after=5)
        else:
            await ctx.send(f"예약 로그 채널을 찾을 수 없습니다.", delete_after=5)
    else:
        await ctx.send(f"해당 사용자의 예약을 찾을 수 없습니다.", delete_after=5)

@bot.command()
async def 티켓닫기(ctx):
    if ctx.channel.category_id == TICKET_CATEGORY_ID and ctx.channel.name.startswith('티켓-'):
        await ctx.send("이 티켓은 종료되었습니다.")
        await ctx.channel.delete()
        await ctx.send(f"티켓 채널 {ctx.channel.mention}이 종료되었습니다.", delete_after=5)
    else:
        await ctx.send("이 명령어는 티켓 채널에서만 사용할 수 있습니다.", delete_after=5)

@bot.command()
async def 티켓(ctx):
    if ctx.channel.id != TICKET_REQUEST_CHANNEL_ID:
        await ctx.send("이 명령어는 티켓 요청 채널에서만 사용할 수 있습니다.", delete_after=5)
        return

    # 기존 티켓 드롭다운 메시지 삭제
    async for message in ctx.channel.history(limit=10):
        if message.author == bot.user and message.content.startswith("티켓을 생성하려면"):
            await message.delete()

@tasks.loop(minutes=5)
async def send_ticket_message():
    channel = bot.get_channel(1267503788554453086)
    if channel:
        # 기존 메시지 삭제
        async for message in channel.history(limit=10):
            if message.author == bot.user and message.content.startswith("티켓을 생성하려면"):
                await message.delete()
                break

        # 새로운 티켓 드롭다운 메시지 보내기
        select = TicketSelect()
        view = View()
        view.add_item(select)
        await channel.send("티켓을 생성하려면 아래 드롭다운에서 유형을 선택하세요:", view=view)
    else:
        print(f"채널 ID {1267503788554453086}을(를) 찾을 수 없습니다.")

#봇 토큰
bot.run('MTI0ODY5NDM4MDE2OTEzODI0Ng.GWhiU_.unvSp0LCBN7RYQhdDlJrVj3WCnUoQ0vlZx5XHo')